import { AuthServiceProvider } from './../auth-service/auth-service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { AngularFireStorage } from 'angularfire2/storage';

@Injectable()
export class JobsProvider {
  jobs: Observable<any[]>;
  constructor(public http: HttpClient, private db: AngularFireDatabase, private store: AngularFireStorage, private authService: AuthServiceProvider) {
    this.authService.userAuth().subscribe(res => {
      if (!res || !res.uid) {
        this.jobs = null;
      }
    });

    this.authService.userChanged.subscribe(userData => {
      if (userData){
        this.loadJobs(userData.userType);
      }
    })
  }

  public loadJobs(userType: string){
    if (userType == 'employer'){
      var userId = this.authService.currentUserId();
      console.log('Filtering jobs for employer ' + userId);
      this.jobs = this.db.list('jobs', ref => ref.orderByChild('companyId').equalTo(userId)).valueChanges();
    }
    else{
      console.log('getting all jobs for candidate user type');
      this.jobs = this.db.list('jobs').valueChanges();
    }
  }

  public getJobs()
  {
    return this.jobs;
  }

  public updateJob(job: any){
    return new Promise((resolve, reject)=>{
      resolve('');
    });
  }

  public addJob(job: any){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('jobs');
      itemsRef.push(job).then(x => { x.update({ id: x.key });resolve('Ok');}, _=> reject('Failed'))
    });
  }

  public addApplication(job: any, fileName: string = 'dummy'){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('applications');
      itemsRef.push({jobId: job.id, userId: this.authService.currentUserId(), fileName: fileName}).then(x => { x.update({ id: x.key });resolve('Ok');}, _=> reject('Failed'))
    });
  }

  public getApplicationsForJob(jobId: string){
    console.log('getting applications for job id - ' + jobId);
    return this.db.list('applications', ref => ref.orderByChild('jobId').equalTo(jobId)).valueChanges();
  }

  public getApplicationUrl(fileName: any){
    
    return new Promise((resolve, reject)=>{
      console.log('getting url for ' + 'applications/'+fileName);
      var ref = this.store.storage.ref('applications/'+fileName);
      ref.getDownloadURL().then(x => resolve(x));
    });
  }

}
