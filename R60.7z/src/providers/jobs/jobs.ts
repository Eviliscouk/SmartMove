import { LoadingController, Platform } from 'ionic-angular';
import { AuthServiceProvider } from './../auth-service/auth-service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { AngularFireStorage, AngularFireUploadTask } from 'angularfire2/storage';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/first';
import 'rxjs/add/operator/map';
import "rxjs/Rx";
import { Camera } from '@ionic-native/camera';

declare var window: any

@Injectable()
export class JobsProvider {
  jobs: Observable<any[]>;
  constructor(public http: HttpClient, private db: AngularFireDatabase, private store: AngularFireStorage, private platform: Platform, private authService: AuthServiceProvider, private loadCtrl:  LoadingController, private camera: Camera) {
    this.authService.userAuth().subscribe(res => {
      if (!res || !res.uid) {
        this.jobs = null;
      }
    });

    this.authService.userChanged.subscribe(userData => {
      if (userData){
        this.loadJobs(userData.userType);
      }
    })
  }

  public loadJobs(userType: string){
    if (userType == 'employer'){
      var userId = this.authService.currentUserId();
      console.log('Filtering jobs for employer ' + userId);
      this.jobs = this.db.list('jobs', ref => ref.orderByChild('companyId').equalTo(userId)).valueChanges();
    }
    else{
      console.log('getting all jobs for candidate user type');
      this.jobs = this.db.list('jobs').valueChanges();
    }
  }

  public getJobs()
  {
    return this.jobs;
  }

  public updateJob(job: any){
    return new Promise((resolve, reject)=>{
      resolve('');
    });
  }

  public addJob(job: any){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('jobs');
      itemsRef.push(job).then(x => { x.update({ id: x.key });resolve('Ok');}, _=> reject('Failed'))
    });
  }

  public addApplication(job: any, fileName: string = 'dummy.mp4'){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('applications');
      itemsRef.push({jobId: job.id, userId: this.authService.currentUserId(), applicantName: this.authService.currentUserName(), status: 'new', appliedDate: new Date().toUTCString(), fileName: fileName}).then(x => { x.update({ id: x.key });resolve('Ok');}, _=> reject('Failed'))
    });
  }

  public uploadApplicationToStorrage(job: any) {
    this.getMedia(job).then(fileUri => {
      this.uploadFile(job, fileUri);
    })
  }

  public updateApplicationStatus(job: any){
      const itemsRef = this.db.object('applications/'+job.id);
      return itemsRef.update({status: job.status, reviewedDate: new Date().toUTCString()});    
  }

  public getApplicationsForJob(jobId: string){
    var observable = this.db.list<any>('applications', ref => ref.orderByChild('jobId').equalTo(jobId)).valueChanges();
    return observable;
  }

  getMedia(job: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const options: any = {
        sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM,
        mediaType: this.camera.MediaType.VIDEO,
        destinationType: this.camera.DestinationType.FILE_URI
      }

      this.camera.getPicture(options).then((imageData) => {
        resolve(imageData);
      }, (err) => {
        console.log(err);
        reject(err);
      });
    })    
  }

  uploadFile(job: any, fileUri: any) {
    let loader = this.loadCtrl.create({
      content: "Uploading..."
    });
    loader.present();

    if (this.platform.is("android")) {
      fileUri = "file://" + fileUri
    }

    window.resolveLocalFileSystemURL(fileUri, (fileEntry) => {
      console.log('video File located at -' + fileUri);
      fileEntry.file((resFile) => {
    
        var reader = new FileReader();
        reader.onloadend = (evt: any) => {
    
          console.log('finished reading file!');
          var imgBlob = new Blob([evt.target.result], {type: 'video/mp4'});
          //var name = job.id + this.authService.currentUserId();
          const id = Math.random().toString(36).substring(2);
          console.log('Blob Size = '+ imgBlob.size);
          console.log('Blob file created');
          console.log('New file name = ' + id);
          
          //var appRef = this.store.ref('applications/').child('test'+id+'.mp4');
          //var uploadTask: AngularFireUploadTask = appRef.put(imgBlob); 
          var uploadTask = this.store.upload('applications/'+'test'+id+'.mp4', imgBlob);
          
          uploadTask.snapshotChanges().subscribe((x)=> {
            console.log('upload state change - ' + x.state);
            var percent = x.bytesTransferred / x.totalBytes * 100;
            console.log(percent + "% done");
            
          })
          uploadTask.percentageChanges().subscribe((x)=> {
            console.log(x + "% done");
          })
          uploadTask.catch((err) => {
            console.log(JSON.stringify(err)); loader.dismiss();
          })
          uploadTask.downloadURL().subscribe(x => {
            var downloadURL = x;
            console.log('upload complete! - ' + downloadURL);
            this.addApplication(job, id).then(() => {
              console.log('application added!');
              loader.dismiss();
          })
          uploadTask.then((x) => {
            console.log('upload complete! - ' + x.downloadURL);
          });            
          });
        };
    
        reader.readAsArrayBuffer(resFile);
      })
    });
  }

  public getApplicationUrl(fileName: any){
    console.log('getting ref for file - ' + fileName);
    return this.store.storage.ref('applications/'+fileName).getDownloadURL();
  }

}
