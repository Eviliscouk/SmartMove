import { Platform } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { AngularFireStorage, AngularFireUploadTask } from 'angularfire2/storage';

declare var window: any

@Injectable()
export class ImghandlerProvider {
  imageUri : String
  constructor(public http: HttpClient, private camera : Camera, private store: AngularFireStorage, private platform: Platform) {
    console.log('Hello ImghandlerProvider Provider');
  }

  uploadProfileImage(){
    return this.uploadHandler();
  }

  async captureImage() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }

    return await this.camera.getPicture(options)
}

async uploadHandler() {
  const base64 = await this.captureImage();
  return this.createUploadTask(base64);
 }

createUploadTask(file: string) {

  const id = Math.random().toString(36).substring(2);
  const filePath = id+'.jpg';

  var image = 'data:image/jpg;base64,' + file;
  var task = this.store.ref('userPics/'+filePath).putString(image, 'data_url');

  task.percentageChanges().subscribe(x => console.log(x+'% uploaded'));
  return task;
}

}
