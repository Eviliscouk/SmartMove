export class UserData {  
    constructor(public uid: string, public userType: string, public displayName: string, public photoURL: string) {}
  }