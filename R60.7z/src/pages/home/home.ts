import { JobDetailPage } from './../job-detail/job-detail';
import { JobsProvider } from './../../providers/jobs/jobs';
import { JobEditPage } from './../job-edit/job-edit';
import { Component } from '@angular/core';
import { NavController, AlertController, App, ItemSliding } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  segment: string = 'Jobs';
  jobs: Observable<any[]>;
  constructor(public navCtrl: NavController, public app: App, public authService: AuthServiceProvider, public alertCtrl: AlertController, private jobsService: JobsProvider) {
    this.jobs = this.jobsService.getJobs();
  }

  ionViewCanEnter() {
    //return this.authService.authenticated();
  }

  onLogout(){
    // Remove API token 
    this.authService.logout();
    const root = this.app.getRootNav();
    root.popToRoot();
  }

  segmentChanged(ev: any){
    
  }

  goToJobDetail(job: any){
    console.log('loading job -' + job.id);
    this.navCtrl.push(JobDetailPage, {job: job});
  }

  applyToJob(job: any){
    this.jobsService.addApplication(job);
  }

  addFavourite(slidingItem: ItemSliding, jobData: any) {

  }

  removeFavourite(slidingItem: ItemSliding, job: any, title: string) {
  }

  onAddJob()
  {
    this.navCtrl.push(JobEditPage, {mode: 'New'});
  }

}
