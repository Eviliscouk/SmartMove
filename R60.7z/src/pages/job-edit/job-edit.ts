import { JobsProvider } from './../../providers/jobs/jobs';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@IonicPage()
@Component({
  selector: 'page-job-edit',
  templateUrl: 'job-edit.html',
})
export class JobEditPage implements OnInit {
  mode = 'New';
  jobForm: FormGroup;
  job: any;
  constructor(private navParams: NavParams,
              private toastCtrl: ToastController,
              private navCtrl: NavController,
              private loadingCtrl: LoadingController,
              private authService: AuthServiceProvider,
              private jobsService: JobsProvider) {
  }

  ngOnInit() {
    this.mode = this.navParams.get('mode');
  
    if (this.mode == 'Edit') {
      this.job = this.navParams.get('job');
    }

    this.initializeForm();
  }

  private initializeForm() {
    let title = null;
    let description = null;
    let location = null;
    
    if (this.mode == 'Edit') {
      title = this.job.title;
      description = this.job.description;
      location = this.job.location;
    }

    this.jobForm = new FormGroup({
      'title': new FormControl(title, Validators.required),
      'description': new FormControl(description, Validators.required),
      'location': new FormControl(location, Validators.required),
    });

    this.jobForm.enable();
    console.log('initalised form');
  }

  onSubmit() {
    const value = this.jobForm.value;
    if (!this.job){
      this.job = {}; 
      this.job.companyName = this.authService.currentUserName();    
      this.job.companyId = this.authService.currentUserId(); 
      this.job.postedAt = new Date().toUTCString();
    }

    this.job.title = value.title;
    this.job.description = value.description;
    this.job.location = value.location;

    if (this.mode == 'Edit') {
      this.jobsService.updateJob(this.job).then(() => {
       
        const toast = this.toastCtrl.create({
          message: 'Job Updated!',
          duration: 1500,
          position: 'bottom'
        });
        toast.present();
        
      })
      .catch(err =>{
        const toast = this.toastCtrl.create({
          message: err,
          duration: 1500,
          position: 'bottom'
        });
        toast.present();
      });
      
    } else {
      this.jobsService.addJob(this.job).then(() => {
       
        const toast = this.toastCtrl.create({
          message: 'Job Added!',
          duration: 1500,
          position: 'bottom'
        });
        toast.present();
        
      })
      .catch(err =>{
        console.log(err);
        const toast = this.toastCtrl.create({
          message: err,
          duration: 1500,
          position: 'bottom'
        });
        toast.present();
      });
    }
    this.jobForm.reset();
    this.navCtrl.popToRoot();
  }

}
