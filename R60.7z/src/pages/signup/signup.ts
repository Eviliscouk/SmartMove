import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';
import { NgForm } from '@angular/forms';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { TabsPage } from '../tabs/tabs';

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  user: string;
  pass: string;
  type: string;
  submitted = false;

  constructor(public navCtrl: NavController, private authService: AuthServiceProvider, public navParams: NavParams, private loadingCtrl: LoadingController, private alertCtrl: AlertController) {
  }

  onSignup(form: NgForm) {
    this.submitted = true;

    if (form.valid) {
      const loading = this.loadingCtrl.create({
        content: 'Creating Account ...'
      });
      loading.present();
      this.authService.signup(this.user, this.pass).then(data => {
        
        console.log(data);
        this.authService.addUserInfo({uid: data.uid, userType: this.type}).then(()=>{
          loading.dismiss();
          this.navCtrl.push(TabsPage);
        })
      })
      .catch(error => {
        loading.dismiss();
        const alert = this.alertCtrl.create({
          title: 'Creating Account Failed!',
          message: error.message,
          buttons: ['Ok']
        });
        alert.present();
      })
    }
  }

}
