import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, FabContainer, LoadingController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { SocialSharing } from '@ionic-native/social-sharing';
import { JobsProvider } from '../../providers/jobs/jobs';

@IonicPage()
@Component({
  selector: 'page-job-detail',
  templateUrl: 'job-detail.html',
})
export class JobDetailPage {
 job: any;
 applications = [];
 showApplications = true;
  constructor(public navCtrl: NavController, public navParams: NavParams, private jobService: JobsProvider, private iab: InAppBrowser, private authService: AuthServiceProvider, private socialSharing: SocialSharing, private loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    this.job = this.navParams.get('job');
    this.getApplications();
    console.log(this.job);
  }

  ionViewCanEnter() {
    return this.authService.authenticated();
  }

  getApplications(){
    console.log('getting applications!');
    this.jobService.getApplicationsForJob(this.job.id).subscribe(x => {
      console.log('getting application urls!');
      x.forEach(
        (x:any) => {
          this.jobService.getApplicationUrl(x.fileName).then(url => {
            console.log(url);
            this.applications.push(url);
          })
        });
    })
  }

  addApplication(){
    this.jobService.addApplication(this.job);
  }

  openWebpage(url: string) {
    const options: InAppBrowserOptions = { zoom: 'no', presentationstyle:'pagesheet' };
    this.iab.create(url, '_self', options);
  }

  compilemsg():string{
    var msg = this.job.title + "-" + this.job.url;
    return msg.concat(" \n Sent from my Awesome App !");
  }

  regularShare(){
    var msg = this.compilemsg();
    return this.socialSharing.share(msg, null, null, null);
  }

  whatsappShare(){
    var msg  = this.compilemsg();
     return this.socialSharing.shareViaWhatsApp(msg, null, null);
   }

  twitterShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaTwitter(msg, null, null);
  }

  facebookShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaFacebook(msg, null, null);
  }

  instagramShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaInstagram(msg, this.job.urlToImage);
  }

  openSocial(network: string, fab: FabContainer) {
    let loading = this.loadingCtrl.create({
      content: `Posting to ${network}`,
    });
    loading.onWillDismiss(() => {
      fab.close();
    });
    loading.present();

    var p: Promise<any>;
    if (network == 'WhatsApp')
      p = this.whatsappShare();
    else if (network == 'Instagram')
      p = this.instagramShare();
    else if (network == 'Twitter')
      p = this.twitterShare();
    else if (network == 'Facebook')
      p = this.facebookShare();
    
    p.then(() => {
      console.log('Posted to '+network);
      loading.dismiss();
    })
    .catch(()=> {
      console.log('Failed Post to '+network)
      loading.dismiss();
    })
  }

}
