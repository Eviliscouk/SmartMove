import { JobsProvider } from './../../providers/jobs/jobs';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { TabsPage } from '../tabs/tabs';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { NgForm } from '@angular/forms';
import { SignupPage } from '../signup/signup';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  name: string;
  pass: string;
  submitted = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, private jobsService: JobsProvider, private alrtCtrl: AlertController) {
  }

  ionViewDidLoad(){
    if (this.authService.authenticated()){      
      this.goToApp();
    }
    else{
    this.authService.userChanged.subscribe(x => { 
      console.log('user found - loading tabs');
          this.navCtrl.push(TabsPage, {}, {animate: false});
    });
  }
      
  }

  goToApp(){
    this.navCtrl.push(TabsPage);
  }

  login(){    
    
    this.authService.login(this.name, this.pass)
    .then(value => {
    })
    .catch(err => {
      console.log('Something went wrong:',);
      var alert = this.alrtCtrl.create({
        title: "Login failure",
        message: err.message + ' ,please try again!',
        buttons: ["Ok"]
      });
      alert.present();
    });
  }

  onLogin(form: NgForm) {
    this.submitted = true;

    if (form.valid) {
      this.login();
    
    form.reset();
    this.submitted = false;
    }
  }

  onSignup() {
    this.navCtrl.push(SignupPage);
  }

  forgotPass() {

  }

}
