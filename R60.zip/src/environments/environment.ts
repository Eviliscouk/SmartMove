export const environment = {
    production: false,
    firebase: {
      apiKey: 'AIzaSyAYUwAfYHu00ZAE2XInN9zAzDp1U1WDLp4',
      authDomain: 'rec60-21c2e.firebaseapp.com',
      databaseURL: 'https://rec60-21c2e.firebaseio.com',
      projectId: 'rec60-21c2e',
      storageBucket: 'rec60-21c2e.appspot.com',
      messagingSenderId: '634380500563'
    }
  };