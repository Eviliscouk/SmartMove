import { UserData } from './../../model/UserData';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-candidate-profile-modal',
  templateUrl: 'candidate-profile-modal.html',
})
export class CandidateProfileModalPage {

  avatar: string;
  displayName: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl : ViewController, private authService : AuthServiceProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CandidateProfileModalPage');
    var userId = this.navParams.get('userId');
    this.loaduserdetails(userId);
  }

  loaduserdetails(userId: string) {
    if (userId)
      this.authService.lookupUser(userId).then(x => {
        this.setUserData(x[0]);
      })   
  }

  private setUserData(userData: UserData)
  {
    this.displayName = userData.displayName;
    console.log('Loading data for profile - ' + JSON.stringify(userData));
    console.log('user url = ' + userData.photoUrl);
    this.avatar = userData.photoUrl;
    console.log('avatar - ' + this.avatar);
  }

  public closeModal(){
    this.viewCtrl.dismiss();
  }

}
