import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CandidateProfileModalPage } from './candidate-profile-modal';

@NgModule({
  declarations: [
    CandidateProfileModalPage,
  ],
  imports: [
    IonicPageModule.forChild(CandidateProfileModalPage),
  ],
})
export class CandidateProfileModalPageModule {}
