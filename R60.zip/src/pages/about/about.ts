import { SocialSharing } from '@ionic-native/social-sharing';
import { Component } from '@angular/core';
import { NavController, LoadingController, FabContainer } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

  appIconUrl: string;
  constructor(public navCtrl: NavController, public authService: AuthServiceProvider, private socialSharing: SocialSharing, private loadingCtrl: LoadingController) {

  }

  ionViewCanEnter() {
    return this.authService.authenticated();
  }

  compilemsg():string{
    var msg = 'Klipp is awesome !';
    return msg.concat(" \n Sent from my Awesome App !");
  }

  regularShare(){
    var msg = this.compilemsg();
    return this.socialSharing.share(msg, null, null, null);
  }

  whatsappShare(){
    var msg  = this.compilemsg();
     return this.socialSharing.shareViaWhatsApp(msg, null, null);
   }

  twitterShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaTwitter(msg, null, null);
  }

  facebookShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaFacebook(msg, null, null);
  }

  instagramShare(){
    var msg  = this.compilemsg();
    return this.socialSharing.shareViaInstagram(msg, this.appIconUrl);
  }

  openSocial(network: string, fab: FabContainer) {
    let loading = this.loadingCtrl.create({
      content: `Posting to ${network}`,
    });
    loading.onWillDismiss(() => {
      fab.close();
    });
    loading.present();

    var p: Promise<any>;
    if (network == 'WhatsApp')
      p = this.whatsappShare();
    else if (network == 'Instagram')
      p = this.instagramShare();
    else if (network == 'Twitter')
      p = this.twitterShare();
    else if (network == 'Facebook')
      p = this.facebookShare();
    
    p.then(() => {
      console.log('Posted to '+network);
      loading.dismiss();
    })
    .catch(()=> {
      console.log('Failed Post to '+network)
      loading.dismiss();
    })
  }

}
