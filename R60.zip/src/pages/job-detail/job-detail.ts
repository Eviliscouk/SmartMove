import { CandidateContactModalPage } from './../candidate-contact-modal/candidate-contact-modal';
import { CandidateProfileModalPage } from './../candidate-profile-modal/candidate-profile-modal';
import { ProfilePage } from './../profile/profile';
import { ApplicationDetailPage } from './../application-detail/application-detail';
import { JobEditPage } from './../job-edit/job-edit';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, FabContainer, LoadingController, ToastController, ModalController, ItemSliding } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { SocialSharing } from '@ionic-native/social-sharing';
import { JobsProvider } from '../../providers/jobs/jobs';

@IonicPage()
@Component({
  selector: 'page-job-detail',
  templateUrl: 'job-detail.html',
})
export class JobDetailPage {
 segment: string = 'Applications';
 job: any;
 applications = [];
 jobVidURI: any;
 avatar: string;
 showApplications = false;
 newApplicationCount = 0;
 contactRequestCount = 0;

  constructor(public navCtrl: NavController, public navParams: NavParams, private jobService: JobsProvider, private modalCtrl: ModalController, private toastCtrl: ToastController, private iab: InAppBrowser, private authService: AuthServiceProvider, private socialSharing: SocialSharing, private loadingCtrl: LoadingController) {
    this.getRandomUserProfilePic();
    
    this.jobService.getApplicationUrl('dummy.mp4').then(url => {
      console.log('added - default url' + url); 
      this.jobVidURI = url;
  });
  }

  ionViewDidLoad() {
    this.job = this.navParams.get('job');
    this.showApplications = this.authService.isEmployerLoggedIn();
    
    if (this.showApplications)
      this.getApplications();
    
      console.log(this.job);
  }

  ionViewCanEnter() {
    return this.authService.authenticated();
  }

  onEditJob(){
    this.navCtrl.push(JobEditPage, {mode: 'Edit'});
  }

  segmentChanged(ev: any){
    
  }

  onViewApplication(app: any){
    this.navCtrl.push(ApplicationDetailPage, {job: this.job, app: app});
  }

  onViewProfile(userId: string){
    this.presentProfileModal(userId);
  }

  presentProfileModal(userId: string) {
    let profileModal = this.modalCtrl.create(CandidateProfileModalPage, { userId: userId });
    profileModal.present();
  }

  presentCandidateContactModal(userId: string) {
    let profileModal = this.modalCtrl.create(CandidateContactModalPage, { userId: userId });
    profileModal.present();
  }

  processApp(slidingItem: ItemSliding, app: any, action: string){
    if (action === 'play'){
      this.onViewApplication(app);
    }
    else if (action === 'reject'){
      app.status = 'rejected';
      this.jobService.updateApplicationStatus(app);
    }
    else if (action === 'shortList'){
      app.isShortListed = true;
      this.jobService.updateApplicationStatus(app);
    }
    else if (action === 'view'){
      this.onViewProfile(app.userId);
    }
    else if (action === 'contact'){
      app.hasHadContact = true;
      this.jobService.updateApplicationStatus(app).then(_=>{
        this.presentCandidateContactModal(app.userId);
      })
    }

    slidingItem.close();
  }

  async getRandomUserProfilePic(){
    var x: any = await this.authService.getRandomUserPic();
    this.avatar = x.results[0].picture.thumbnail;
  }

  getApplications(){
    console.log('getting applications for - ' + this.job.id);
    this.jobService.getApplicationsForJob(this.job.id).then(x => {
      console.log('all applications = ' + JSON.stringify(x));
      this.applications = [];
      this.newApplicationCount = 0;
      this.contactRequestCount = 0;
      x.forEach((app: any)=> {
        
        this.jobService.getApplicationUrl(app.fileName).then(url => {
            console.log('added - ' + url);
            app.url = url 
            this.applications.push(app);
            if (app.status == 'new')
              this.newApplicationCount++;
            if (app.hasHadContact)
              this.contactRequestCount++;
            console.log('added - ' + JSON.stringify(app));
        });
      });
    });
    
    //console.log('applications - ' + JSON.stringify(this.applications));
  }

  addApplication(){
    this.jobService.addApplication(this.job).then(x => {this.getApplications();});
  }

  apply(){
    this.jobService.uploadApplicationToStorrage(this.job).then(x => {this.getApplications();});
  }


  openWebpage(url: string) {
    const options: InAppBrowserOptions = { zoom: 'no', presentationstyle:'pagesheet' };
    this.iab.create(url, '_self', options);
  }

  

}
