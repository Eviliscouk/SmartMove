import { Component } from '@angular/core';
import { NavController, AlertController, App } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public app: App, public authService: AuthServiceProvider, public alertCtrl: AlertController) {

  }

  logout(){
    // Remove API token 
    this.authService.logout();
    const root = this.app.getRootNav();
    root.popToRoot();
  }

}
