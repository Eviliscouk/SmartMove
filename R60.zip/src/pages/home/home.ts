import { JobDetailPage } from './../job-detail/job-detail';
import { JobsProvider } from './../../providers/jobs/jobs';
import { JobEditPage } from './../job-edit/job-edit';
import { Component } from '@angular/core';
import { NavController, AlertController, App, ItemSliding, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  segment: string = 'Jobs';
  jobs: Observable<any[]>;
  canAddJobs: boolean = false;
  images = [];
  appCount = [];
  favImages = [];
  favAppCount = [];

  favourites: Observable<any[]>;

  constructor(public navCtrl: NavController, public app: App, public authService: AuthServiceProvider, public alertCtrl: AlertController, private jobsService: JobsProvider, private toastCtrl: ToastController) {
    
    this.jobsService.jobsLoaded.subscribe(x => {
      this.setLists();
    })
    
    this.canAddJobs = this.authService.isEmployerLoggedIn();
  }

  ionViewCanEnter() {
    //return this.authService.authenticated();
  }

  setLists(){
    this.jobs = this.jobsService.getJobs();
      this.jobs.subscribe(x => { x.forEach(y => { this.getProfilePic(false); this.getAppCount(y, false); }); });
      this.favourites = this.jobsService.getFavourites();
      this.favourites.subscribe(x => { console.log('favourites loaded - ' + x.length); x.forEach(y => { this.getProfilePic(true); this.getAppCount(y, true); }); });
  }

  onLogout(){
    // Remove API token 
    this.authService.logout();
    const root = this.app.getRootNav();
    root.popToRoot();
  }

  segmentChanged(ev: any){
    
  }

  async getProfilePic(fav: boolean){
    var response : any = await this.authService.getRandomUserPic();
    console.log(JSON.stringify(response));
    var path = response.results[0].picture.thumbnail;
    console.log('adding Path - ' + path);
    if(fav)
      this.favImages.push(path);
    else
      this.images.push(path);
  }

  async getAppCount(job: any, fav: boolean){
    console.log('requesting app count for job - ' + job.title);
    var apps = await this.jobsService.getApplicationsForJob(job.id);
    console.log('received app array' + JSON.stringify(apps));
    //this.appCount.push(apps ? apps.length : 0); 
    if(fav) 
      this.favAppCount.push(this.randomIntFromInterval(1,25)); 
    else
      this.appCount.push(this.randomIntFromInterval(1,25)); 
  }

  randomIntFromInterval(min,max)
  {
    return Math.floor(Math.random()*(max-min+1)+min);
  }

  goToJobDetail(job: any){
    console.log('loading job -' + job.id);
    this.navCtrl.push(JobDetailPage, {job: job});
  }

  addFavourite(slidingItem: ItemSliding, jobData: any) {
    this.jobsService.addFavourite(jobData).then(() => {
      var userType = this.authService.isEmployerLoggedIn ? 'employer' : 'candidate';
      this.jobsService.loadJobs(userType);
      const toast = this.toastCtrl.create({
        message: 'Job - ' + jobData.title + ' added to favourites!',
        duration: 2000,
        position: 'middle'
        });
      toast.present();
    })
    slidingItem.close();
  }

  removeFavourite(slidingItem: ItemSliding, jobData: any, title: string) {
    this.jobsService.removeFavourite(jobData).then(() => {
      var userType = this.authService.isEmployerLoggedIn ? 'employer' : 'candidate';
      this.jobsService.loadJobs(userType);
      const toast = this.toastCtrl.create({
        message: 'Job - ' + jobData.title + ' removed from favourites!',
        duration: 2000,
        position: 'middle'
        });
      toast.present();
    })
    slidingItem.close();
  }

  onAddJob()
  {
    this.navCtrl.push(JobEditPage, {mode: 'New'});
  }

  onCloseJob(slidingItem: ItemSliding, job: any, title: string)
  {
    this.jobsService.closeJob(job);
    slidingItem.close();
  }

}
