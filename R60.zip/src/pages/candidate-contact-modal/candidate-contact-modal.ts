import { UserData } from './../../model/UserData';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@IonicPage()
@Component({
  selector: 'page-candidate-contact-modal',
  templateUrl: 'candidate-contact-modal.html',
})
export class CandidateContactModalPage {
  contactMessage: string;
  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, private viewCtrl: ViewController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CandidateContactModalPage');
    var userId = this.navParams.get('userId');
    console.log('candidate user Id = ' + userId);
    this.loaduserdetails(userId);
  }

  loaduserdetails(userId: string) {
    if (userId)
      this.authService.lookupUser(userId).then(x => {
        this.setUserData(x[0]);
      })   
  }

  private setUserData(userData: UserData)
  {
    this.contactMessage = 'Contact details for - ' + userData.displayName;
  }

  public closeModal(){
    this.viewCtrl.dismiss();
  }

}
