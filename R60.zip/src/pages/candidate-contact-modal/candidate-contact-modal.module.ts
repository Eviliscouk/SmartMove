import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CandidateContactModalPage } from './candidate-contact-modal';

@NgModule({
  declarations: [
    CandidateContactModalPage,
  ],
  imports: [
    IonicPageModule.forChild(CandidateContactModalPage),
  ],
})
export class CandidateContactModalPageModule {}
