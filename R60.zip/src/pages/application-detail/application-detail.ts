import { JobsProvider } from './../../providers/jobs/jobs';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@IonicPage()
@Component({
  selector: 'page-application-detail',
  templateUrl: 'application-detail.html',
})
export class ApplicationDetailPage {

  app: any;
  job: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private jobService: JobsProvider, private toastCtrl: ToastController, private authService: AuthServiceProvider) {
  }

  ionViewCanEnter() {
    return this.authService.authenticated();
  }

  ionViewDidLoad() {
    this.job = this.navParams.get('job');
    this.app = this.navParams.get('app');
    console.log('loaded with job - ' + JSON.stringify(this.job));
    console.log('loaded with app - ' + JSON.stringify(this.app));
  }

  swipe(e, jobApp: any) {

    var updateApplicationStatus = false;
    
    if (e.direction == 2 && jobApp.status != 'liked') {
      console.log('liked application - ' + jobApp.id)
      jobApp.status = 'liked';
      updateApplicationStatus = true;
    }
    else if (e.direction == 4 && jobApp.status != 'disliked'){
      jobApp.status = 'disliked';
      updateApplicationStatus = true;
    }
    else{
      console.log('ignoringswipe direction = ' + e.direction);
    }

    if (updateApplicationStatus) {
      jobApp.isRejected = jobApp.status == 'disliked';
      jobApp.isLiked = jobApp.status == 'liked';
    this.jobService.updateApplicationStatus(jobApp).then(()=>{
      const toast = this.toastCtrl.create({
        message: 'You '+ jobApp.status +' this application from ' + jobApp.applicantName + ' for position ' + this.job.title,
        duration: 3000,
        position: 'top'
        });
      toast.present();
    });
  }
}

}
