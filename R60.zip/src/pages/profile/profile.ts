import { UserData } from './../../model/UserData';
import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, App } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { ImghandlerProvider } from '../../providers/imghandler/imghandler';

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  avatar: string;
  displayName: string;
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public authService: AuthServiceProvider, public app: App, public zone: NgZone, public alertCtrl: AlertController, private imghandler: ImghandlerProvider) {
  }

  ionViewDidLoad() {
    console.log('loading uer details');
    var userId = this.navParams.get('userId');
    this.loaduserdetails(userId);
  }

  onLogout(){
    // Remove API token 
    this.authService.logout();
    const root = this.app.getRootNav();
    root.popToRoot();
  }

  loaduserdetails(userId: string) {
    if (userId)
      this.authService.lookupUser(userId).then(x => {
        this.setUserData(x[0]);
      })
    else
      this.setUserData(this.authService.userData);    
  }

  private setUserData(userData: UserData)
  {
    this.displayName = userData.displayName;
    console.log('Loading data for profile - ' + JSON.stringify(userData));
    console.log('user url = ' + userData.photoUrl);
    this.avatar = userData.photoUrl;
    console.log('avatar - ' + this.avatar);
  }

  editimage() {
    let statusalert = this.alertCtrl.create({
      buttons: ['okay']
    });
    this.imghandler.uploadProfileImage().then((url: any) => {
      this.authService.updateUserImage(url).then((res: any) => {
        statusalert.setTitle('Updated');
        statusalert.setSubTitle('Your profile pic has been changed successfully!!');
        statusalert.present();
        this.zone.run(() => {
        this.avatar = url;
      })  
      }).catch((err) => {
          statusalert.setTitle('Failed');
          statusalert.setSubTitle('Your profile pic was not changed');
          statusalert.present();
      })
      })
  }

  editname() {
    let statusalert = this.alertCtrl.create({
      buttons: ['okay']
    });
    let alert = this.alertCtrl.create({
      title: 'Edit Nickname',
      inputs: [{
        name: 'nickname',
        placeholder: 'Nickname'
      }],
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
        handler: data => {
 
        }
      },
      {
        text: 'Edit',
        handler: data => {
          if (data.nickname) {
            this.authService.updateUserDisplayName(data.nickname).then(() => {
              statusalert.setTitle('Updated');
                statusalert.setSubTitle('Your nickname has been changed successfully!!');
                statusalert.present();
                this.zone.run(() => {
                  this.displayName = data.nickname;
                })                             
            })
            .catch((err) => {
                statusalert.setTitle('Failed');
                statusalert.setSubTitle('Your nickname was not changed');
                statusalert.present();
            })
          }
        }
        
      }]
    });
    alert.present();
  }

}
