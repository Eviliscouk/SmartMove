import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { SignupPage } from '../signup/signup';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { TabsPage } from '../tabs/tabs';

@IonicPage()
@Component({
  selector: 'page-welcome',
  templateUrl: 'welcome.html',
})
export class WelcomePage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, private alrtCtrl: AlertController) {
  }

  ionViewDidLoad(){
    if (this.authService.authenticated()){      
      this.goToApp();
    }
      
  }

  async login(){
    this.navCtrl.push(LoginPage);
  }
  
  signup(){
    this.navCtrl.push(SignupPage);
  }

  goToApp(){
    this.navCtrl.push(TabsPage);
  }

}
