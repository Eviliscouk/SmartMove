import { TabsPage } from './../../pages/tabs/tabs';
import { NavController } from 'ionic-angular';
import { UserData } from './../../model/UserData';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase } from 'angularfire2/database';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/first';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import "rxjs/Rx";


@Injectable()
export class AuthServiceProvider {

  user: Observable<firebase.User>;
  userName: string;
  userId: string;
  isLoggedIn: boolean;
  userChanged: Subject<UserData> = new Subject<UserData>();
  userData: UserData;


  constructor(public http: HttpClient, private firebaseAuth: AngularFireAuth, private db: AngularFireDatabase) {
    console.log('auth-');
    console.log(firebaseAuth.authState);
    this.user = firebaseAuth.authState;
    this.user.subscribe(res => {
      if (res && res.uid) {
        this.userId = res.uid;
        this.userName = res.email;
        this.isLoggedIn = true;

        console.log('user logged in - looking for user data');
        this.lookupUser(res.uid).then(u =>{
          console.log('userData retrieved - ' + u);
          this.userData = u[0];
          console.log('userData changed - ' + this.userData);
          this.userChanged.next(this.userData);
      })
      } else {
        this.isLoggedIn = false;
        this.userId = '';
        this.userName = '';
      }
    });

  }

  login(email: string, password: string) {
    return this.firebaseAuth
      .auth
      .signInWithEmailAndPassword(email, password);
  }
 
  logout() {
    this.firebaseAuth
      .auth
      .signOut();
  }

  signup(email: string, password: string) {
    return this.firebaseAuth
      .auth
      .createUserWithEmailAndPassword(email, password);      
  }

  public addUserInfo(user: any){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('Users');
      itemsRef.push(user).then(_ => {
        this.userData = user;
        console.log('userData changed - ' + this.userData);
        this.userChanged.next(user);
        resolve('Ok')
      }, _=> reject('Failed'))
    });
  }

  public updateUserImage(url: string){
    const itemsRef = this.db.object('Users/'+this.userData.uid);
    return itemsRef.update({photoURL: url});    
}

public updateUserDisplayName(name: string){
  const itemsRef = this.db.object('Users/'+this.userData.uid);
  return itemsRef.update({displayName: name});   
} 

public getRandomUserPic(){
  return this.http.get('https://randomuser.me/api/?inc=picture').toPromise();
}

  public lookupUser(userId: string){
    return this.db.list('Users', ref => ref.orderByChild('uid').equalTo(userId).limitToFirst(1)).valueChanges()
    .map(userDataRecords => userDataRecords.map((u : UserData) => u))
    .first()
    .toPromise();
  }

  authenticated() : boolean {
    return this.isLoggedIn;  
  }

  currentUserName() : string {
    return this.userName;
  }

  currentUserId() : string {
    return this.userId;
  }

  isEmployerLoggedIn() : boolean {
    return this.userData && this.userData.userType == 'employer';
  }

  userAuth(): Observable<firebase.User> {
    return this.user;
  }
}
