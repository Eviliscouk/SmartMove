import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class AuthServiceProvider {

  user: Observable<firebase.User>;
  isLoggedIn: boolean;

  constructor(public http: HttpClient, private firebaseAuth: AngularFireAuth ) {
    console.log('auth-');
    console.log(firebaseAuth.authState);
    this.user = firebaseAuth.authState;
    this.user.subscribe(res => {
      if (res && res.uid) {
        this.isLoggedIn = true;
      } else {
        this.isLoggedIn = false;
      }
    });
  }

  login(email: string, password: string) {
    return this.firebaseAuth
      .auth
      .signInWithEmailAndPassword(email, password);
  }
 
  logout() {
    this.firebaseAuth
      .auth
      .signOut();
  }

  signup(email: string, password: string) {
    return this.firebaseAuth
      .auth
      .createUserWithEmailAndPassword(email, password);      
  }
 
  // Returns whether the user is currently authenticated
  // Could check if current token is still valid
  authenticated() : boolean {
    return this.isLoggedIn;  
  }

}
