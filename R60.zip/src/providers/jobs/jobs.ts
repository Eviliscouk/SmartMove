import { LoadingController, Platform } from 'ionic-angular';
import { AuthServiceProvider } from './../auth-service/auth-service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { AngularFireStorage, AngularFireUploadTask } from 'angularfire2/storage';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/first';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import "rxjs/Rx";
import { Camera } from '@ionic-native/camera';

declare var window: any

@Injectable()
export class JobsProvider {
  jobs: Observable<any[]>;
  favourites: Observable<any[]>;
  public jobsLoaded = new Subject<any>();
  constructor(public http: HttpClient, private db: AngularFireDatabase, private store: AngularFireStorage, private platform: Platform, private authService: AuthServiceProvider, private loadCtrl:  LoadingController, private camera: Camera) {
    this.authService.userAuth().subscribe(res => {
      if (!res || !res.uid) {
        this.jobs = null;
      }
    });

    this.authService.userChanged.subscribe(userData => {
      if (userData){
        this.loadJobs(userData.userType);
      }
    })
  }

  public loadJobs(userType: string){
    if (userType == 'employer'){
      var userId = this.authService.currentUserId();
      console.log('Filtering jobs for employer ' + userId);
      this.getFavouriteRecords().then(x => {
        console.log('got favourites!');
        console.log(JSON.stringify(x));
        this.jobs = this.db.list('jobs', ref => ref.orderByChild('companyId').equalTo(userId)).valueChanges().map(_jobs => _jobs.filter((job: any) => x.find(y => y.jobid === job.id) == null));
        this.favourites = this.db.list('jobs', ref => ref.orderByChild('companyId').equalTo(userId)).valueChanges().map(_jobs => _jobs.filter((job: any) => x.find(y => y.jobid === job.id) != null));
        this.jobsLoaded.next();
      })      
    }
    else{
      console.log('getting all jobs for candidate user type');
      this.getFavouriteRecords().then(x => {
        console.log('got favourites!');
        this.jobs = this.db.list('jobs').valueChanges().map(_jobs => _jobs.filter((job: any) => !x.some(y => y.jobId === job.id)));
        this.favourites = this.db.list('jobs').valueChanges().map(_jobs => _jobs.filter((job: any) => x.some(y => y.jobId === job.id)));
        this.jobsLoaded.next();
      })  
    }
  }

  public getJobs()
  {
    return this.jobs;
  }

  public getFavourites()
  {
    return this.favourites;
  }

  private getFavouriteRecords(){
    return this.db.list<any>('favourites', ref => ref.orderByChild('uid').equalTo(this.authService.currentUserId())).valueChanges().first().toPromise();
  }

  public updateJob(job: any){
    const itemsRef = this.db.object('jobs/'+job.id);
    return itemsRef.update(job);    
  }

  public addJob(job: any){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('jobs');
      itemsRef.push(job).then(x => { x.update({ id: x.key });resolve('Ok');}, _=> reject('Failed'))
    });
  }

  public addFavourite(job: any){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.database.ref('favourites');
      itemsRef.push({jobid: job.id, uid: this.authService.currentUserId()}).then(x => { x.update({ id: x.key }); resolve('Ok');}, _=> reject('Failed'));
    });
  }

  public removeFavourite(job: any){
    return new Promise((resolve, reject)=>{  
    console.log('removing favourite')
    this.db.list<any>('favourites', ref => ref.orderByChild('uid').equalTo(this.authService.currentUserId())).valueChanges().first().toPromise().then(x => {
      console.log('got favourites list - ' + JSON.stringify(x));

      var fav : any = x.find((f: any) => f.jobid === job.id)
        if (fav){
          const favRef = this.db.object('favourites/'+fav.id);
          favRef.remove().then(_ => resolve()).catch(_ => reject());
        }
        else{
          reject()
        }
      })
    }) 
  }

  public closeJob(job: any){
    const itemsRef = this.db.object('jobs/'+job.id);
    return itemsRef.update({status: 'closed', closedDate: new Date().toUTCString()});
  }

  public addApplication(job: any, fileName: string = 'dummy.mp4'){
    return new Promise((resolve, reject)=>{
      const itemsRef = this.db.list('applications');
      itemsRef.push({jobId: job.id, userId: this.authService.currentUserId(), applicantName: this.authService.currentUserName(), status: 'new', appliedDate: new Date().toUTCString(), fileName: fileName}).then(x => { 
        x.update({ id: x.key });

        resolve('Ok');
      },
       _=> reject('Failed'))
    });
  }

  public uploadApplicationToStorrage(job: any) {
    this.getMedia(job).then(fileUri => {
      this.uploadFile(job, fileUri);
    })
  }

  public updateApplicationStatus(application: any){
      const itemsRef = this.db.object('applications/'+application.id);
      return itemsRef.update({status: application.status, reviewedDate: new Date().toUTCString()});    
  }

  public getApplicationsForJob(jobId: string){
    return this.db.list<any>('applications', ref => ref.orderByChild('jobId').equalTo(jobId)).valueChanges().first().toPromise();
  }

  getMedia(job: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const options: any = {
        sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM,
        mediaType: this.camera.MediaType.VIDEO,
        destinationType: this.camera.DestinationType.FILE_URI
      }

      this.camera.getPicture(options).then((imageData) => {
        resolve(imageData);
      }, (err) => {
        console.log(err);
        reject(err);
      });
    })    
  }

  uploadFile(job: any, fileUri: any) {
    let loader = this.loadCtrl.create({
      content: "Uploading..."
    });
    loader.present();

    if (this.platform.is("android")) {
      fileUri = "file://" + fileUri
    }

    window.resolveLocalFileSystemURL(fileUri, (fileEntry) => {
      console.log('video File located at -' + fileUri);
      fileEntry.file((resFile) => {
    
        var reader = new FileReader();
        reader.onloadend = (evt: any) => {
    
          console.log('finished reading file!');
          var imgBlob = new Blob([evt.target.result], {type: 'video/mp4'});
          //var name = job.id + this.authService.currentUserId();
          const id = Math.random().toString(36).substring(2);
          console.log('Blob Size = '+ imgBlob.size);
          console.log('Blob file created');
          console.log('New file name = ' + id);
          
          //var appRef = this.store.ref('applications/').child('test'+id+'.mp4');
          //var uploadTask: AngularFireUploadTask = appRef.put(imgBlob); 
          var uploadTask = this.store.upload('applications/'+'test'+id+'.mp4', imgBlob);
          
          uploadTask.snapshotChanges().subscribe((x)=> {
            console.log('upload state change - ' + x.state);
            var percent = x.bytesTransferred / x.totalBytes * 100;
            console.log(percent + "% done");
            
          })
          uploadTask.percentageChanges().subscribe((x)=> {
            console.log(x + "% done");
          })
          uploadTask.catch((err) => {
            console.log(JSON.stringify(err)); loader.dismiss();
          })
          uploadTask.downloadURL().subscribe(x => {
            var downloadURL = x;
            console.log('upload complete! - ' + downloadURL);
            this.addApplication(job, id).then(() => {
              console.log('application added!');
              loader.dismiss();
          })
          uploadTask.then((x) => {
            console.log('upload complete! - ' + x.downloadURL);
          });            
          });
        };
    
        reader.readAsArrayBuffer(resFile);
      })
    });
  }

  public getApplicationUrl(fileName: any){
    console.log('getting ref for file - ' + fileName);
    return this.store.storage.ref('applications/'+fileName).getDownloadURL();
  }

}
