import {Pipe} from '@angular/core';
 
@Pipe({
  name: 'jobFilter'
})
export class JobFilter {
  transform(value, args) {
    return value;
  }
}