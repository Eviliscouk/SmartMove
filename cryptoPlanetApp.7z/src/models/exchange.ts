export class Exchange { 
    constructor(public MARKET: string, public PRICE:string){}
  }