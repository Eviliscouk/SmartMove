export class CoinOption {  
    constructor(public symbol: string, public hidden: boolean) {}
  }