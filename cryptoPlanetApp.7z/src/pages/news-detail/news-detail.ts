import { NewsItem } from './../../models/newsItem';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, FabContainer } from 'ionic-angular';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';

@IonicPage()
@Component({
  selector: 'page-news-detail',
  templateUrl: 'news-detail.html',
})
export class NewsDetailPage {
  article: NewsItem
  constructor(public navCtrl: NavController, public navParams: NavParams, private iab: InAppBrowser, private loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsDetailPage');
    this.article = this.navParams.get('article');
  }

  openWebpage(url: string) {
    const options: InAppBrowserOptions = { zoom: 'no', presentationstyle:'pagesheet' };
    this.iab.create(url, '_self', options);
  }

  openSocial(network: string, fab: FabContainer) {
    let loading = this.loadingCtrl.create({
      content: `Posting to ${network}`,
      duration: (Math.random() * 1000) + 500
    });
    loading.onWillDismiss(() => {
      fab.close();
    });
    loading.present();
  }

}
